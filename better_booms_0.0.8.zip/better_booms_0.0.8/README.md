# Better Booms
## Explosions start fires

This mod is a big like TrueNukes, except it doesn't murder your UPS. 